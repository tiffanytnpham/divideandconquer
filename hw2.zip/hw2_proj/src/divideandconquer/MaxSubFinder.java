package divideandconquer;

import divideandconquer.LinkedList.Node;

public class MaxSubFinder {

/*	static int findHighArr(int[] arr) {
		int high = 0;
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] > arr[high])
				high = i;
		}
		return high;
	}
	
	static int findLowArr(int[] arr) {
		int low = 0;
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] < arr[low])
				low = i;
		}
		return low;
	}
*/
	static Triple<Integer,Integer,Integer> findMaxSubarray(int[] arr, int low, int high){
		
		if(high == low)
			return (new Triple<> (low, high, arr[low]));
		else {
			int mid = (high + low) / 2;

			Triple<Integer,Integer,Integer> l = findMaxSubarray(arr, low, mid);
			Triple<Integer,Integer,Integer> r = findMaxSubarray(arr, mid + 1, high);
			Triple<Integer, Integer, Integer> c = findMaxCrossingArray(arr, low, mid, high);
			
			if(l.getLast() >= r.getLast() && l.getLast() >= c.getLast())
				return (l);
			else if(r.getLast() >= l.getLast() && r.getLast() >= c.getLast())
				return (r);
			else
				return (c);
		}
	}
	
	static Triple<Integer,Integer,Integer> findMaxCrossingArray(int arr[], int low, int mid, int high){
		int leftSum = Integer.MIN_VALUE, leftMax = 0;
		int rightSum = Integer.MIN_VALUE, rightMax = 0;
		int sum = 0;
		for(int i = mid; i >= low; i--) {
			sum += arr[i];
			if (sum > leftSum) {
				leftSum = sum;
				leftMax = i;
			}
		}
		sum = 0;
		for(int j = mid + 1; j <= high; j++) {
			sum += arr[j];
			if (sum > rightSum) {
				rightSum = sum;
				rightMax = j;
			}
		}
		return (new Triple<> (leftMax, rightMax, leftSum + rightSum));
	}

	public static Triple<Integer,Integer,Integer> getMaxSubarray(int[] arr){
		int high = arr.length - 1;
		int low = 0;
		
		return(findMaxSubarray(arr, low, high));
	}
	
	static Triple<Node,Node,Integer> findMaxSublist(LinkedList list, Node low, Node high){
		
		if(high == low)
			return (new Triple<> (low, high, low.data));
		else {
			Node mid = list.middle(low, high);

			Triple<Node,Node,Integer> l = findMaxSublist(list, low, mid);
			Triple<Node,Node,Integer> r = findMaxSublist(list, mid.next, high);
			Triple<Node, Node, Integer> c = findMaxCrossingList(list, low, mid, high);
			
			if(l.getLast() >= r.getLast() && l.getLast() >= c.getLast())
				return (l);
			else if(r.getLast() >= l.getLast() && r.getLast() >= c.getLast())
				return (r);
			else
				return (c);
		}
	}
	
	public static Triple<Node,Node,Integer> findMaxCrossingList(LinkedList list, Node low, Node mid, Node high){
		int leftSum = Integer.MIN_VALUE;
		int rightSum = Integer.MIN_VALUE;
		Node leftMax = null;
		Node rightMax = null;
		int sum = 0;
		Node i = mid;
		Node j = mid.next;
		while(i != null) {
			sum += i.data;
			if (sum > leftSum) {
				leftSum = sum;
				leftMax = i;
			}
			i = i.prev;
		}
		sum = 0;
		while(j != null) {
			sum += j.data;
			if (sum > rightSum) {
				rightSum = sum;
				rightMax = j;
			}
			j = j.next;
		}

		return (new Triple<> (leftMax, rightMax, leftSum + rightSum));
	}
	public static Triple<Node,Node,Integer> getMaxSubList(LinkedList list){
		Node high = list.tail;
		Node low = list.head;
		
		return(findMaxSublist(list, low, high));
	}

}
