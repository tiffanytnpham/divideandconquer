package divideandconquer;

public class MergeSorter {
	public static void mergeSort(int[] arr) {
		MergeSorter sorter = new MergeSorter();
		sorter.sort(arr, 0, arr.length - 1);
	}
	
	void sort(int arr[], int start, int end) {
		if(start < end) {
			int mid = start + (end - start) / 2;
			
			sort(arr, start, mid);
			sort(arr, mid + 1, end);
			
			merge(arr, start, mid, end);
		}
	}
	
	void merge(int arr[], int start, int mid, int end){
		int leftSize = mid - start + 1;
		int rightSize = end - mid;
		
		int left[] = new int[leftSize];
		int right[] = new int[rightSize];
		
		for(int i =  0; i < leftSize; i++) 
			left[i] = arr[start + i];
		
		for(int j =  0; j < rightSize; j++) 
			right[j] = arr[mid + 1 + j];
		
		
		int i = 0, j = 0;
		int k = start;
		while(i < leftSize && j < rightSize) {
			if(left[i] <= right[j]){
				arr[k] = left[i];
				i++;
			}
			else {
				arr[k] = right[j];
				j++;
			}
			k++;
		}
		while(i < leftSize) {
			arr[k] = left[i];
			i++;
			k++;
		}
		while(j < rightSize) {
			arr[k] = right[j];
			j++;
			k++;
		}
		
	}
}
