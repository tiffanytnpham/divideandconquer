package divideandconquer;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class MergeSorterTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		int[] nums = new int[]{4,3,2,1};
		int[] sorted = new int[] {1,2,3,4};
		MergeSorter.mergeSort(nums);
		assertArrayEquals(sorted,nums);
	}
	
	@Test
	public void test1() {
		int[] nums = new int[]{-6, -2, 8, 3, 4, -2};
		int[] sorted = new int[] {-6, -2, -2, 3, 4, 8};
		MergeSorter.mergeSort(nums);
		assertArrayEquals(sorted,nums);
	}
	
	@Test
	public void test2() {
		int[] nums = new int[]{-2,1,-3, 4,-1, 2,1,-5,4};
		int[] sorted = new int[] {-5, -3, -2, -1, 1, 1, 2, 4, 4};
		MergeSorter.mergeSort(nums);
		assertArrayEquals(sorted,nums);
	}
	
	@Test
	public void test3() {
		int[] nums = new int[]{80, -2, 4, -123, 6, 78, 9, -6};
		int[] sorted = new int[] {-123, -6, -2, 4, 6, 9, 78, 80};
		MergeSorter.mergeSort(nums);
		assertArrayEquals(sorted,nums);
	}
	
	@Test
	public void test4() {
		int[] nums = new int[]{-1, -2, -3, -4};
		int[] sorted = new int[] {-4, -3, -2, -1};
		MergeSorter.mergeSort(nums);
		assertArrayEquals(sorted,nums);
	}
	
	@Test
	public void test5() {
		int[] nums = new int[]{4};
		int[] sorted = new int[] {4};
		MergeSorter.mergeSort(nums);
		assertArrayEquals(sorted,nums);
	}

}
